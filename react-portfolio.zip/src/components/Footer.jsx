import React from "react";

export default function Footer() {
  return (
    <footer style={{textAlign:"center", padding:"20px"}}>
      © {new Date().getFullYear()} Prakash Gautam
    </footer>
  );
}
